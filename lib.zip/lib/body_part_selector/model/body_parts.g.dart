// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names

part of 'body_parts.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_BodyParts _$$_BodyPartsFromJson(Map<String, dynamic> json) => _$_BodyParts(
      head: json['head'] as bool? ?? false,
      neck: json['neck'] as bool? ?? false,
      leftShoulder: json['leftShoulder'] as bool? ?? false,
      leftUpperArm: json['leftUpperArm'] as bool? ?? false,
      leftElbow: json['leftElbow'] as bool? ?? false,
      leftLowerArm: json['leftLowerArm'] as bool? ?? false,
      leftHand: json['leftHand'] as bool? ?? false,
      rightShoulder: json['rightShoulder'] as bool? ?? false,
      rightUpperArm: json['rightUpperArm'] as bool? ?? false,
      rightElbow: json['rightElbow'] as bool? ?? false,
      rightLowerArm: json['rightLowerArm'] as bool? ?? false,
      rightHand: json['rightHand'] as bool? ?? false,
      upperBody: json['upperBody'] as bool? ?? false,
      lowerBody: json['lowerBody'] as bool? ?? false,
      leftUpperLeg: json['leftUpperLeg'] as bool? ?? false,
      leftKnee: json['leftKnee'] as bool? ?? false,
      leftLowerLeg: json['leftLowerLeg'] as bool? ?? false,
      leftFoot: json['leftFoot'] as bool? ?? false,
      rightUpperLeg: json['rightUpperLeg'] as bool? ?? false,
      rightKnee: json['rightKnee'] as bool? ?? false,
      rightLowerLeg: json['rightLowerLeg'] as bool? ?? false,
      rightFoot: json['rightFoot'] as bool? ?? false,
      abdomen: json['abdomen'] as bool? ?? false,
      vestibular: json['vestibular'] as bool? ?? false,
    );

Map<String, dynamic> _$$_BodyPartsToJson(_$_BodyParts instance) =>
    <String, dynamic>{
      'head': instance.head,
      'neck': instance.neck,
      'leftShoulder': instance.leftShoulder,
      'leftUpperArm': instance.leftUpperArm,
      'leftElbow': instance.leftElbow,
      'leftLowerArm': instance.leftLowerArm,
      'leftHand': instance.leftHand,
      'rightShoulder': instance.rightShoulder,
      'rightUpperArm': instance.rightUpperArm,
      'rightElbow': instance.rightElbow,
      'rightLowerArm': instance.rightLowerArm,
      'rightHand': instance.rightHand,
      'upperBody': instance.upperBody,
      'lowerBody': instance.lowerBody,
      'leftUpperLeg': instance.leftUpperLeg,
      'leftKnee': instance.leftKnee,
      'leftLowerLeg': instance.leftLowerLeg,
      'leftFoot': instance.leftFoot,
      'rightUpperLeg': instance.rightUpperLeg,
      'rightKnee': instance.rightKnee,
      'rightLowerLeg': instance.rightLowerLeg,
      'rightFoot': instance.rightFoot,
      'abdomen': instance.abdomen,
      'vestibular': instance.vestibular,
    };
